﻿#include <iostream>  
#include <fstream>  
#include <string>  
#include <sstream>  
using namespace std;


int main() {
	fstream os("input.txt", ios_base::in | ios_base::binary); //以二进制方式打开文件
	fstream ios("output.txt", ios_base::out | ios_base::binary);

	int linenum = 1;
	string line;//一个空字符串，用与表现每一行的结束；
	while (getline(os, line)) {
		ios << linenum++ << ": " << line << endl;
	}
	
	
	
	


	return 0;
}
